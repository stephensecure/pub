import React from "react";
import "./App.css";
import Company from "./Company";

const App = () => {
  return (
    <div className="container">
      <Company />
    </div>
  );
}

export default App;
